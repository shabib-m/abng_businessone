<?php
/**
 * @file
 * Spanish language transliteration overrides.
 */
$overrides['es'] = array(
  0xE1 => 'a',
  0xE9 => 'e',
  0xED => 'i',
  0xF3 => 'o',
  0xFA => 'u',
  0xF1 => 'n',
);
