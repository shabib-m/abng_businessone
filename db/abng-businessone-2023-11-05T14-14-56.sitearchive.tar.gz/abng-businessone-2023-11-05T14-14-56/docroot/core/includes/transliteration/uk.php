<?php
/**
 * @file
 * Ukrainian language transliteration overrides.
 */
$overrides['uk'] = array(
  0x490 => 'G',
  0x491 => 'g',
  0x404 => 'YE',
  0x454 => 'ye',
  0x418 => 'Y',
  0x438 => 'y',
);
