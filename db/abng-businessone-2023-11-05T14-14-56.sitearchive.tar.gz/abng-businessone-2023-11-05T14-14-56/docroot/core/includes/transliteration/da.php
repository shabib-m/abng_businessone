<?php
/**
 * @file
 * Danish language transliteration overrides.
 */
$overrides['da'] = array(
  0xC5 => 'Aa',
  0xC6 => 'Ae',
  0xD8 => 'Oe',
  0xE5 => 'aa',
  0xE6 => 'ae',
  0xF8 => 'oe',
);
